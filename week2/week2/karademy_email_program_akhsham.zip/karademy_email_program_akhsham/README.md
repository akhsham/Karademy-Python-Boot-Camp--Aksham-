#This program help you with split your E-Mail CSV files to names and domains, also correct "." problem at GMAILs.

##What does this code do?
###This code take your E-Mail list, after clean the raw addresses it will give you 3 different CSV files:
###1-List all domains include "@gmail.com"!
###2-List all GMAIL accounts and remove "." inside account names.
###3-List all rest of E-Mails which exists in your raw list.


##How Use It?

###1-Make a new directory on your local storage and save a copy of code in this directory.
###2-You need a clear CSV file which include emails separately in first column and and how many you want rows! but an E-Mail in each cell.
###3-Save CSV file in the same directory as code saved.
###4-Rename CSV file to : raw_list.CSV
###5-Run the code!


##PAY ATTENTION: You can find out your list E-Mails quantity in IDE.
